<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Reception1 - ISFCE - DvpWeb</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
        <script src="jquery-3.1.1.min/jquery-3.1.1.min.js"></script>
        <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <h1>Réception des données provenant du formulaire1</h1>
            <?php
            var_dump($_POST);
            // EXERCICE écrire les données en DB
            ?>
        </div>
    </body>
</html>
